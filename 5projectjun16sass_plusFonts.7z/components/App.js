import React, { Component } from 'react';
import Greeting from './greetings';
import NavigationBar from './navigationBar';
require('./app.scss');


export default class App extends Component {
	render(){
		return (
			<div className="container">
				<h1>I am In</h1>
				<NavigationBar />
				{this.props.children}
			</div>
		)
	}
}

/*
class App extends Component {

	render(){
		return (
			<div className="container">
				<h1>Hello World Gone Nowhere</h1>
			</div>
		)
	}

}
*/
