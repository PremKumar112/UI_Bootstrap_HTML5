var express =require('express');
var validateInput = require('../shared/validations/signup');

let router = express.Router();

router.post('/', (req, res)=>{

  const { errors, isValid } = validateInput(req.body);
  //console.log(errors);
  if(!isValid){
    res.status(400).json(errors);
  }

});

module.exports= router;
