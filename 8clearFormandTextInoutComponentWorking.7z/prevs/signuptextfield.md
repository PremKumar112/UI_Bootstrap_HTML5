<div className={classnames("form-group", { 'has-error': errors.username})}>
  <label className="control-label">UserName</label>
  <input
    placeholder="Enter Your UserName Here"
    onChange={this.onChange}
    value={this.state.username}
    type="text"
    name="username"
    className="form-control"
    />
    {lex.username && <span className="help-block">{lex.username}</span>}
    </div>
  <div className={classnames("form-group", { 'has-error': errors.email})}>
        <label className="control-label">Email Address</label>
        <input
          placeholder="Enter Email"
          onChange={this.onChange}
          value={this.state.email}
          type="text"
          name="email"
          className="form-control"
          />
        {lex.email && <span className="help-block">{lex.email}</span>}
      </div>
  <div className={classnames("form-group", { 'has-error': errors.password})}>
        <label className="control-label">Password</label>
        <input
          placeholder="Enter Password"
          onChange={this.onChange}
          value={this.state.password}
          type="password"
          name="password"
          className="form-control"
          />
      {lex.password && <span className="help-block">{lex.password}</span>}
      </div>
  <div className={classnames("form-group", { 'has-error': errors.passwordConfirmation})}>
        <label className="control-label">Confirm Password</label>
        <input
          placeholder="Confirm Password"
          onChange={this.onChange}
          value={this.state.passwordConfirmation}
          type="password"
          name="passwordConfirmation"
          className="form-control"
          />
      {lex.passwordConfirmation && <span className="help-block">{lex.passwordConfirmation}</span>}
      </div>
