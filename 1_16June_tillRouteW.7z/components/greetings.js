import React, { Component } from 'react';

export default class Greeting extends Component{

  render(){
    return(
      <div className="row">
  		<h1>Hello From Greetings Rendered in React for aAll</h1>
  		</div>
    )
  }

}
