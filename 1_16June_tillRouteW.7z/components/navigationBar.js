import React, { Component } from 'react';
import { browserHistory } from 'react-router';



export default class NavigationBar extends Component{

  render(){

    return(
      <nav className="navbar navbar-default">
        <div className="container">

        <div className="navbar-header">
          <a className="navbar-brand" href="#" onClick={()=>browserHistory.push(`/about`)}>Red Dice</a>
        </div>

        <div className="collapse navbar-collapse">
          <ul className="nav navbar-nav pull-right">
            <li><a href="">Sign Up </a></li>
          </ul>
        </div>

        </div>
      </nav>
    )
  }

}
