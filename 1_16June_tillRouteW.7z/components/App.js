import React, { Component } from 'react';
import Greeting from './greetings';
import NavigationBar from './navigationBar';

export default class App extends Component {
	render(){
		return (
			<div className="container">
				{this.props.children}
			</div>
		)
	}
}

/*
class App extends Component {

	render(){
		return (
			<div className="container">
				<h1>Hello World Gone Nowhere</h1>
			</div>
		)
	}

}
*/
