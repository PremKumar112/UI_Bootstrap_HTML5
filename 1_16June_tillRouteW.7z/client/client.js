import React from 'react';
import { render } from 'react-dom';
import ReactDOM from 'react-dom';
import { Router, Route, browserHistory, IndexRoute } from 'react-router';
import { Provider } from 'react-redux';
import { createStore, applyMiddleware} from 'redux';
import Promise from 'redux-promise';
import App from '../components/App';
import Greeting from '../components/greetings';
import NavigationBar from '../components/navigationBar';
import reducers from '../reducers';

const routes =(
	<Route path="/" component={App} >
		<IndexRoute component={NavigationBar} />
		<Route path="/about" component={Greeting} />
	</Route>
)


const createStoreWithMiddleware = applyMiddleware(Promise)(createStore);

ReactDOM.render(
	<Provider store={createStoreWithMiddleware(reducers)}>
	<Router history={browserHistory} routes={routes} />
	</Provider>,
	document.getElementById('app')
);
