import React, { Component } from 'react';

export default class SignupPage extends Component{

  render(){
    return(
      <div className="container">
        <h1>Sign Up Now</h1>
      </div>
    )
  }

}
