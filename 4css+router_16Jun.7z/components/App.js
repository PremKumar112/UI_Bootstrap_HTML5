import React, { Component } from 'react';
import Greeting from './greetings';
import NavigationBar from './navigationBar';
// require('./app.css');


export default class App extends Component {
	render(){
		return (
			<div className="container">
				<NavigationBar />
				{this.props.children}
			</div>
		)
	}
}

/*
class App extends Component {

	render(){
		return (
			<div className="container">
				<h1>Hello World Gone Nowhere</h1>
			</div>
		)
	}

}
*/
