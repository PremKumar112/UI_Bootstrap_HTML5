import React, { Component } from 'react';
import axios from 'axios';
import timezones from '../../client/datas/timezones';
import map from 'lodash/map';
import _ from 'lodash';

export default class SignupForm extends Component{

    constructor(props){
      super(props);
      this.state={
        username: '',
        email: '',
        password: '',
        passwordConfirmation: '',
        timezone: '',
        errors: {}
      }
      this.onInputChange = this.onInputChange.bind(this);
      this.submitForm = this.submitForm.bind(this);
    }

    onInputChange(e){
      this.setState({ [e.target.name]: e.target.value});
    }
    submitForm(e){
      e.preventDefault();
      this.setState({ errors: {} });
      var request = this.props.userSignupRequest(this.state);
      request.then(function(response){
        console.log(response);
      })
      .catch((error)=>{
	      this.setState({ errors: error.response.data });
      })
    }

render(){
      const { errors } = this.state;
      let lex={};
      if(errors!==undefined){
        lex=errors;
      }
      const options = map(timezones, (val, key)=>
        <option key={val} value={val}>{key}</option>
      );
return(
  <form onSubmit={this.submitForm}>
    <h1>Join Our Community</h1>
    <div className="form-group">
      <label className="control-label">UserName</label>
      <input
        placeholder="Enter Your UserName Here"
        onChange={this.onInputChange}
        value={this.state.username}
        type="text"
        name="username"
        className="form-control"
        />
        {lex.username && <span className="help-block">{lex.username}</span>}
        </div>
          <div className="form-group">
            <label className="control-label">Email Address</label>
            <input
              placeholder="Enter Email"
              onChange={this.onInputChange}
              value={this.state.email}
              type="text"
              name="email"
              className="form-control"
              />
            {lex.email && <span className="help-block">{lex.email}</span>}
          </div>
          <div className="form-group">
            <label className="control-label">Password</label>
            <input
              placeholder="Enter Password"
              onChange={this.onInputChange}
              value={this.state.password}
              type="password"
              name="password"
              className="form-control"
              />
          {lex.password && <span className="help-block">{lex.password}</span>}
          </div>
          <div className="form-group">
            <label className="control-label">Confirm Password</label>
            <input
              placeholder="Confirm Password"
              onChange={this.onInputChange}
              value={this.state.passwordConfirmation}
              type="password"
              name="passwordConfirmation"
              className="form-control"
              />
          {lex.passwordConfirmation && <span className="help-block">{lex.passwordConfirmation}</span>}
          </div>
          <div className="form-group">
            <label className="control-label">TimeZone</label>
            <select
            className="form-control"
            name="timezone"
            onChange={this.onInputChange}
            value={this.state.timezone}
            >
            <option value="" disabled>Choose Your Timezone</option>
            {options}
            </select>
            {lex.timezone && <span className="help-block">{lex.timezone}</span>}
          </div>
          <div className="form-group">
            <button className="btn btn-primary btn-lg">
              Sign Up <span className="caret"></span>
            </button>
          </div>

        </form>
      )
    }
}
