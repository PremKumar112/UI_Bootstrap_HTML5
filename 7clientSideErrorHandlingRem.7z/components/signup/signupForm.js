import React, { Component } from 'react';
import axios from 'axios';
import timezones from '../../client/datas/timezones';
import map from 'lodash/map';
import _ from 'lodash';
import classnames from 'classnames';

export default class SignupForm extends Component{

    constructor(props){
      super(props);
      this.state={
        username: '',
        email: '',
        password: '',
        passwordConfirmation: '',
        timezone: '',
        errors: {},
        isLoading: false
      }
      this.onInputChange = this.onInputChange.bind(this);
      this.submitForm = this.submitForm.bind(this);
      this.clearForm = this.clearForm.bind(this);
    }

    onInputChange(e){
      this.setState({ [e.target.name]: e.target.value});
    }


    // isValid function to validate the form inputs on the client side
    isValid(){
      const { errors, isValid }= validateInput(this.state);
      if(!isValid){
        this.setState({ errors });
      }
      return isValid;

    }

    submitForm(e){
      e.preventDefault();
      if(isValid()){
        this.setState({ errors: {}, isLoading: true });
        var request = this.props.userSignupRequest(this.state);
        request.then(function(response){
          console.log(response);
        })
        .catch((error)=>{
  	      this.setState({ errors: error.response.data, isLoading: false });
        })
      }

    }
    clearForm(e){
      this.setState({username: '',
      email: '',
      password: '',
      passwordConfirmation: '',
      timezone: '',
      errors: {}});
    }

render(){
      const { errors } = this.state;
      let lex={};
      if(errors!==undefined){
        lex=errors;
      }
      const options = map(timezones, (val, key)=>
        <option key={val} value={val}>{key}</option>
      );
return(
  <form onSubmit={this.submitForm}>
    <h1>Join Our Community</h1>
    <div className={classnames("form-group", { 'has-error': errors.username})}>
      <label className="control-label">UserName</label>
      <input
        placeholder="Enter Your UserName Here"
        onChange={this.onInputChange}
        value={this.state.username}
        type="text"
        name="username"
        className="form-control"
        />
        {lex.username && <span className="help-block">{lex.username}</span>}
        </div>
      <div className={classnames("form-group", { 'has-error': errors.email})}>
            <label className="control-label">Email Address</label>
            <input
              placeholder="Enter Email"
              onChange={this.onInputChange}
              value={this.state.email}
              type="text"
              name="email"
              className="form-control"
              />
            {lex.email && <span className="help-block">{lex.email}</span>}
          </div>
      <div className={classnames("form-group", { 'has-error': errors.password})}>
            <label className="control-label">Password</label>
            <input
              placeholder="Enter Password"
              onChange={this.onInputChange}
              value={this.state.password}
              type="password"
              name="password"
              className="form-control"
              />
          {lex.password && <span className="help-block">{lex.password}</span>}
          </div>
      <div className={classnames("form-group", { 'has-error': errors.passwordConfirmation})}>
            <label className="control-label">Confirm Password</label>
            <input
              placeholder="Confirm Password"
              onChange={this.onInputChange}
              value={this.state.passwordConfirmation}
              type="password"
              name="passwordConfirmation"
              className="form-control"
              />
          {lex.passwordConfirmation && <span className="help-block">{lex.passwordConfirmation}</span>}
          </div>
          <div className={classnames("form-group", { 'has-error': errors.timezone})}>
            <label className="control-label">TimeZone</label>
            <select
            className="form-control"
            name="timezone"
            onChange={this.onInputChange}
            value={this.state.timezone}
            >
            <option value="" disabled>Choose Your Timezone</option>
            {options}
            </select>
            {lex.timezone && <span className="help-block">{lex.timezone}</span>}
          </div>
          <div className="form-group">
            <button disabled={this.state.isLoading} className="btn btn-primary btn-lg">
              Sign Up <span className="caret"></span>
            </button><span className="warn">
            <button onClick={this.clearForm}
            className="btn btn-warning btn-lg">
              Clear Form</button>
            </span>
          </div>

        </form>
      )
    }
}
