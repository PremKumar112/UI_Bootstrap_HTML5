import React, { Component } from 'react';

export default class Greeting extends Component{

  render(){
    return(
      <div className="container">
  		  <h1>Hello All</h1>
  		</div>
    )
  }

}
