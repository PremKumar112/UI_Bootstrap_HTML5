import React from 'react';
import { render } from 'react-dom';
import ReactDOM from 'react-dom';
import { Router, Route, browserHistory, IndexRoute } from 'react-router';
import { Provider } from 'react-redux';
import { createStore, applyMiddleware} from 'redux';
import thunk from 'redux-thunk';
import Promise from 'redux-promise';
import App from '../components/App';
import Greeting from '../components/greetings';
import NavigationBar from '../components/navigationBar';
import SignupPage from '../components/signup/signupPage';
import reducers from '../reducers';

const routes =(
	<Route path="/" component={App} >
		<IndexRoute component={Greeting} />
		<Route path="signup" component={SignupPage} />
	</Route>
)

const store = createStore(
	(state={}) => state,
	applyMiddleware(thunk)
)

ReactDOM.render(
	<Provider store={store}>
	<Router history={browserHistory} routes={routes} />
	</Provider>, document.getElementById('app'));
