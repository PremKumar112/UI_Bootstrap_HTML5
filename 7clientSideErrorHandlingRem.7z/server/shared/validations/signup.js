var Validator = require('validator');
var isEmpty = require('lodash/isEmpty');


export default function validateInput(data){

  let errors= {};

  if(Validator.isEmpty(data.username)){
    errors.username = 'This Field is Required';
  }
  if(Validator.isEmpty(data.email)){
    errors.email = 'This Field is Required';
  }
  if(!Validator.isEmail(data.email)){
    errors.email = 'Email is inValid';
  }
  if(Validator.isEmpty(data.password)){
    errors.password = 'This Field is Required';
  }
  if(Validator.isEmpty(data.passwordConfirmation)){
    errors.passwordConfirmation = 'This Field is Required';
  }
  if(!Validator.equals(data.password, data.passwordConfirmation)){
    errors.passwordConfirmation= 'Passwords Must Match';
  }
  if(Validator.isEmpty(data.timezone)){
    errors.timezone = 'This Field is Required';
  }
  return{
    errors,
    isValid: isEmpty(errors)
  }
}
