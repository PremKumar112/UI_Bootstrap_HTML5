var express =require('express');

let router = express.Router();

router.post('/', (req, res)=>{

  const { errors, isValid } = validateInput(req.body);
  //console.log(errors);
  if(!isValid){
    res.status(400).json(errors);
  }

});

module.exports= router;
