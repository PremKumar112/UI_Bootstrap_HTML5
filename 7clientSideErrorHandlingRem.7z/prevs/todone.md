change the state object in signup to have another object and then an error property

ctrl + p - to find a file by name
ctr+shift+ p - to open all options in atom
