main file: https://www.typescriptlang.org/docs/handbook/gulp.html


var gulp = require("gulp");
var browserify = require("browserify");
var source = require('vinyl-source-stream');
var watchify = require("watchify");
var gutil = require("gulp-util");
var tsify = require("tsify"); // this gives access to the typescript compiler

var paths = {
    pages: ['src/*.html']
};

var watchedBrowserify = watchify(browserify({
	basedir: '.',
	debug: true,
	entries: ['src/main.ts'],
	cache: {},
	packageCache: {}
}).plugin(tsify));  

// feed the main.ts file into the browserify and then run it throught the tsify plugin

/* In the above you provide watch to the browserify bundler */

gulp.task("copy-html", function(){
	console.log("copy");
	return gulp.src(paths.pages)
	.pipe(gulp.dest("dist"));
});

// above just takes the html from original path (from line 8) and then puts the page into the 
// dist folder so that we can refer the bundle that is made from there

function bundlert(){
	console.log("in Bundle")
	return watchedBrowserify
	.bundle()
	.pipe(source('bundle.js'))
	.pipe(gulp.dest("dist"));
}

// the above will first use the file inside the watchedBrowserify
// and then bundle it to a stream and then we use the vinyl to convert the 
// file into a metadata type of bundle.js

gulp.task("default", ["copy-html"], bundlert); // run the task "copy-html" and call the 
												// bundle callback to run the task asynchronous
watchedBrowserify.on("update", bundlert); // when updated run the bundle function again
watchedBrowserify.on("log", gutil.log); // on logging, use the gutil.log
