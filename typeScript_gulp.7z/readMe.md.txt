npm install -g gulp-cli -- uninstall this later

while doing an npm init; just provide entry as : ./dist/main.js

First Step is to install the following:
1. npm install -g gulp-cli (globally)
2. npm install --save-dev typescript gulp gulp-typescript. (Note: gulp-typescript is a plugin for gulp with typescript)
3. 

/*
return document.write(`<h1 style="color: red;"> ${name} </h1>`);
*/

Before watchify and gulp-util npm.

var gulp = require("gulp");
var browserify = require("browserify");
var source = require('vinyl-source-stream');
var watchify = require("watchify");
var gutil = require("gulp-util");
var tsify = require("tsify");
var paths = {
    pages: ['src/*.html']
};

gulp.task("copy-html", function () {
    return gulp.src(paths.pages)
        .pipe(gulp.dest("dist"));
});

gulp.task("default", ["copy-html"], function () {
    return browserify({
        basedir: '.',
        debug: true,
        entries: ['src/main.ts'],
        cache: {},
        packageCache: {}
    })
    .plugin(tsify)
    .bundle()
    .pipe(source('bundle.js'))
    .pipe(gulp.dest("dist"));
});